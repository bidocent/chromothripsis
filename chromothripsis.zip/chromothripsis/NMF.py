import numpy as np
from sklearn.decomposition import NMF
import scipy.stats
# NMF in Hi-C matrix, compute the distance between two embedding in each window.
class NMF_Window():
    def __init__(self, exp, ref, windows):
        '''
        :param exp:  single experimental chromosome dense matrix
        :param ref:  single referential chromosome dense matrix
        :param chrom: chromosome site file
        :param mask:  mask
        :param windows: the scanning windows
        '''
        self.exp = np.array(exp)
        self.ref = np.array(ref)
        self.windows = windows
    
    def norm_KL_divergence(p,q):
        norm_p=np.linalg.norm(p)
        norm_q=np.linalg.norm(q)
        #M=(p+q)/2
        #return 0.5*scipy.stats.entropy(p, M, base=2)+0.5*scipy.stats.entropy(q, M, base=2)
        if norm_q ==0:
            return 0
        return norm_p/norm_q*scipy.stats.entropy(p, q, base=2)
    
    def train(V, components, iternum, e):
        '''
        非负矩阵分解函数
        :param V:  原始矩阵
        :param components:  要提取多少个特征
        :param iternum: 迭代次数
        :param e: 误差阈值
        :return:
        '''
        V = V.T
        m, n = V.shape  # 4096 * 64
        # 随机初始化两个矩阵
        W = np.random.random((m, components))  # 4096 * 8
        H = np.random.random((components, n))  # 8 * 64

        # 迭代计算过程，循环中使用了numpy的切片操作，可以避免直接使用Python的多重循环，从而提高了运行速度
        for iter in range(iternum):
            V_pre = np.dot(W, H)
            E = V - V_pre

            err = np.sum(E * E)
            print(err)
            if err < e:
                break
            # 对照更新公式
            a = np.dot(W.T, V)
            b = np.dot(W.T, np.dot(W, H))
            H[b != 0] = (H * a / b)[b != 0]

            c = np.dot(V, H.T)
            d = np.dot(W, np.dot(H, H.T))

            W[d != 0] = (W * c / d)[d != 0]
        return W, H

    def nmf_window(self):

        exp_m = self.exp + self.exp.T
        ref_m = self.ref + self.ref.T
        Z = np.hstack((exp_m, ref_m))
        print(type(Z))
        model = NMF(n_components=5, init='random', random_state=0, max_iter=1000)
        W = model.fit_transform(Z)
        H = model.components_
        chr_ = int(H.shape[1] / 2)
        X = H[:, 0:chr_]
        Y = H[:, chr_::]
        dist = []
        for k in range(len(self.windows) - 2):
            # 读取所在windows的数据，并转成稀疏矩阵格式
            start = self.windows[k]
            end = self.windows[k + 2]
            x_window_k = X[:, self.windows[k]:self.windows[k + 2]]
            y_window_k = Y[:, self.windows[k]:self.windows[k + 2]]
            tmp = 0
            tmp = np.linalg.norm(x_window_k[:,:]-y_window_k[:,:])
            dist.append(tmp)
        print(dist)
        return dist
    
    def nmf_X(self):

        exp_m = self.exp + self.exp.T
        ref_m = self.ref + self.ref.T
        Z = np.hstack((exp_m, ref_m))
        model = NMF(n_components=5, init='random', random_state=0, max_iter=1000)
        W = model.fit_transform(Z)
        H = model.components_
        chr_ = int(H.shape[1] / 2)
        X = H[:, 0:chr_]
        Y = H[:, chr_::]

        return X