import numpy as np
import itertools
from scipy.ndimage import gaussian_filter1d
from scipy.sparse import coo_matrix


class PsCurve():
    def __init__(self, matrix, windows):
        '''
        :param exp:  single experimental chromosome dense matrix
        :param ref:  single referential chromosome dense matrix
        :param chrom: chromosome site file
        :param mask:  mask
        :param windows: the scanning windows
        '''
        self.matrix = matrix
        self.windows = windows
    def cal_area(self,bins, hist):
        # 计算直方图面积,8MB = mask_size *2
        a = np.log(8000000)
        tmp = [a]
        tmp.extend(list(bins))
        area = 0
        for i in range(len(hist)):
            area += hist[i] * (tmp[i + 1] - tmp[i])

        return area

    def cal_ps(self,matrix,exp_sum,windows):
        #计算一个矩阵的ps curve面积
        # Image.fromarray(255 - matrix1*100).convert('L').show()
        matrix = matrix + matrix.T
        dist_cont = []
        for k in range(len(windows) - 2):
            # 读取所在windows的数据，并转成稀疏矩阵格式
            start = windows[k]
            # end = windows[k + 2]
            window_k = matrix[windows[k]:windows[k + 2], :]
            tmp = coo_matrix(window_k)
            dist = np.abs(tmp.row - tmp.col + start) * 40000
            data = tmp.data
            if data.shape[0] <= 10:
                dist_cont.append(0)
                continue
            # 合并成dist-contact数据
            dist_data = np.vstack((dist, data)).T
            chri_dist_cont = [(key, sum(val[1] for val in group) / exp_sum) for key, group in
                              itertools.groupby(dist_data[np.argsort(dist_data, axis=0)[:, 0], :], lambda i: i[0])]
            chri_dist_cont = np.array(chri_dist_cont)
            var_smooth = gaussian_filter1d(chri_dist_cont[:, 1], sigma=10)
            area = self.cal_area(np.log(chri_dist_cont[:, 0]), var_smooth)
            dist_cont.append(area)

        return dist_cont
    