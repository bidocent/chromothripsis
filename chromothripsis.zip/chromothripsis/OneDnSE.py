import numpy as np

class Graph():
    
    def __init__(self, NumberOfVertices):
        self.NumberOfVertices = NumberOfVertices
        #self.NumberOfEdges = 0
        self.SumOfDegrees = 0
        self.DegreeOfEachNode = [0.0] * self.NumberOfVertices  # 数组长度为 NumberOfVertices+1

    def addEdge(self, file):
        '''
        add Edges to graph
        edge[0]: FirstNodeID
        edge[1]: SecondNodeID
        edge[2]: Weight
        '''
        for edge in file:
            if edge[2] != 0:
                if edge[0] != edge[1]:
                    #self.NumberOfEdges += 1
                    FirstNodeID = int(edge[0])
                    SecondNodeID = int(edge[1])
                    self.DegreeOfEachNode[FirstNodeID] += edge[2]
                    self.DegreeOfEachNode[SecondNodeID] += edge[2]
                    self.SumOfDegrees += 2 * edge[2]
        

    def OneDStructureEntropy(self, DegreeOfEachNode, SumOfDegrees, NumberOfVertices):
        '''
        SE =0
        循环每个节点：
            if DegreeOfEachNode[i] ！=0：
                SE -= (DegreeOfEachNode[i]/SumOfDegrees)*(np.log(DegreeOfEachNode[i]/SumOfDegrees)/np.log(2))
        return SE
        '''

        SE = 0.0
        for i in range(NumberOfVertices):
            if DegreeOfEachNode[i] != 0:
                SE -= (DegreeOfEachNode[i] / SumOfDegrees) * (np.log(DegreeOfEachNode[i] / SumOfDegrees) / np.log(2))
        return SE